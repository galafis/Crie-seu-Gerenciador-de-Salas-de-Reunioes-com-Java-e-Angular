package com.gerenciadorsalas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeetingRoomManagerApplication {
    public static void main(String[] args) {
        SpringApplication.run(MeetingRoomManagerApplication.class, args);
    }
}