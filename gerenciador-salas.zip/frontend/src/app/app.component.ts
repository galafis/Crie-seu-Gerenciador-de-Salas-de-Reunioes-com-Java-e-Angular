import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<div class="container"><h1>Gerenciador de Salas</h1><app-room-list></app-room-list></div>'
})
export class AppComponent { }